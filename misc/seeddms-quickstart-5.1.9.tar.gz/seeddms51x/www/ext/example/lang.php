<?php
$__lang['de_DE'] = array(
	'folder_contents' => 'Dies war mal "Ordner enthält". Wurde von sample Extension geändert.',
);
?>
